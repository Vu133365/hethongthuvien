import mysql.connector

# 1. Kết nối (Thay đổi password của bạn vào đây)
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="YOUR_PASSWORD",
    database="library_db" # Đảm bảo bạn đã tạo database này trước
)

cursor = db.cursor()

# 2. Tạo bảng 'books'
cursor.execute("""
    CREATE TABLE IF NOT EXISTS books (
        bid VARCHAR(20) PRIMARY KEY,
        title VARCHAR(30),
        author VARCHAR(30),
        status VARCHAR(30)
    )
""")

# 3. Tạo bảng 'books_issued'
cursor.execute("""
    CREATE TABLE IF NOT EXISTS books_issued (
        bid VARCHAR(20) PRIMARY KEY,
        issuedto VARCHAR(30)
    )
""")

print("Đã tạo bảng thành công!")
db.close()